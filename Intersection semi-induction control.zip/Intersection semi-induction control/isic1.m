%% Intersection semi-induction control code %%
clear all;
close all; 
format compact;      
%% creat Vissim-com server
vissim=actxserver('VISSIM.vissim.430');
%% Loading the traffic network
current_path = pwd;
vissim.LoadNet([current_path '\isc.inp']);
vissim.LoadLayout([current_path '\isc.ini']);
%% Simulation settings
simulation=vissim.Simulation;
period_time=3600;
simulation.Period=period_time;
step_time=3;
simulation.Resolution=step_time;
%% Define the network object
vnet=vissim.Net;
%% the traffic demands of the intersetion
vehins=vnet.VehicleInputs;
vehin_1=vehins.Item(1);
vehin_1.set('AttValue', 'Volume', 1268);
vehin_2=vehins.Item(2);
vehin_2.set('AttValue', 'Volume', 1375);
vehin_3=vehins.Item(3);
vehin_3.set('AttValue', 'Volume', 400);
vehin_4=vehins.Item(4);
vehin_4.set('AttValue', 'Volume', 400);
%% the object of the traffic signal control
scs=vnet.SignalControllers;
sc=scs.Item(1);
sgs=sc.SignalGroups;
sg_1=sgs.GetSignalGroupByNumber(1);
sg_2=sgs.GetSignalGroupByNumber(2);
sg_3=sgs.GetSignalGroupByNumber(3);
dets=sc.Detectors;
det_1=dets.GetDetectorByNumber(1);
det_2=dets.GetDetectorByNumber(2);
%% Access to Evalution data
eval = vissim.Evaluation;
%% Acess to DatacollectionPoint object
datacollections = vnet.DataCollections;
dc_1=datacollections.GetDataCollectionByNumber(1);
eval.set('AttValue', 'DataCollection', 1);
%% Acess to link object
links = vnet.links;
%% link_1 = links.GetLinkByNumber(1);
%% link_2 = links.GetLinkByNumber(2);
%% link_3 = links.GetLinkByNumber(3);
%% runing the simulation��semi-induction control��
g0 = 9;           %% ��λ�̵��ӳ�����
MainEtime = 36;    %% �����̵Ʋ���
indCtrlGmax = 180;   %% �̵Ƽ����ӳ�ʱ��
indMainTime = 0;
indSecondTime = 0;
indMainGain = MainEtime;
for i = 0:(period_time*step_time)
    simulation.RunSingleStep;
    pause(0.01);
    if (indMainTime <= MainEtime)
        indMainTime = indMainTime + 1;
        sg_1.set('AttValue','TYPE',2);  
        sg_2.set('AttValue','TYPE',3);
        sg_3.set('AttValue','TYPE',3);
    else
        if (indMainTime <= (indMainGain + g0))||(indMainTime <= indCtrlGmax)
             indMainTime = indMainTime + 1;
             demand = det_1.AttValue('IMPULSE') + det_2.AttValue('IMPULSE');
             if demand == 0;
                 sg_1.set('AttValue','TYPE', 2);  
                 sg_2.set('AttValue','TYPE', 3);
                 sg_3.set('AttValue','TYPE', 3);
             else
                 sg_1.set('AttValue','TYPE', 2);
                 sg_2.set('AttValue','TYPE', 3);
                 sg_3.set('AttValue','TYPE', 3);
                 indMainGain = indMainGain + 1;
             end
        else
            indSecondTime = indSecondTime + 1;
            if (indSecondTime < 30)
                sg_1.set('AttValue','TYPE', 3);
                sg_2.set('AttValue','TYPE', 2);
                sg_3.set('AttValue','TYPE', 3);
            else
                if (indSecondTime < 120)
                    sg_1.set('AttValue','TYPE', 3);
                    sg_2.set('AttValue','TYPE', 3);
                    sg_3.set('AttValue','TYPE', 2);
                else
                    indMainTime = 0;  
                    indMainGain = MainEtime;
                    indSecondTime = 0;
                end
            end 
        end
    end
 end
delete(vissim);
disp('The end'); 
 %% end intersection semi-induction control 
